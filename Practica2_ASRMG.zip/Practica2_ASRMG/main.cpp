#include <iostream>
#include "Camion.h"

using namespace std;

int main()
{

    Camion c1(45);
    Camion c2("asdada","000-1111",45);

    c1.apagar();
    c1.frenar();
    c2.setNumSerie("sssssssssss");

    cout<<c1.getNumSerie()<<endl;
    cout<<c2.getPlaca()<<endl;

    c1.setPlaca(c2.getPlaca());

    c2.encender();
    c2.~Camion();

    return 0;
}
