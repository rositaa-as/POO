#ifndef CAMION_H
#define CAMION_H

#include <iostream>

using namespace std;

class Camion
{
    private:
        ///atributos
        string placa;
        string numSerie;

    public:
        int numAsientos;

        ///metodos
        Camion();///qtor
        ~Camion();
        Camion(string,string,int);
        Camion(string,int);
        Camion(int);

        string getPlaca();
        void setPlaca(string);

        string getNumSerie();
        void setNumSerie(string);

        void encender();
        void apagar();
        void frenar();
};

#endif // CAMION_H
