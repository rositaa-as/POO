#include "Camion.h"

#include<iostream>
using namespace std;

Camion::~Camion(){
    cout<<"hola y adios"<<endl;

}

Camion::Camion()
{
    numAsientos=30;
    placa="444-ASR";
    numSerie="1234567890asdfghjkl";
    //ctor
}
Camion::Camion(string numSerie, string placa, int numAsientos){

    this->numAsientos=numAsientos;
    this->placa=placa;
    this->numSerie=numSerie;
}
Camion::Camion(string p, int n){
    numAsientos=n;
    placa=p;
    numSerie="0000";
}
Camion::Camion(int numAsientos){
    this->numAsientos=numAsientos;
    placa="555-0000";
    numSerie="16546";
}

string Camion::getPlaca(){
    return placa;
}
void Camion::setPlaca(string placa){
    this->placa=placa;

}
string Camion::getNumSerie(){
    return numSerie;
}

void Camion:: setNumSerie(string numSerie){
    this->numSerie=numSerie;

}

void Camion::encender(){

    cout<<"rum rum .."<<endl;
}

void Camion::apagar(){

    cout<<"adios vaquero"<<endl;
}

void Camion::frenar(){

    cout<<"estoy frenando..."<<endl;

}
