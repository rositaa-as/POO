#include <iostream>
#include "Camion.h"

using namespace std;

int main()
{

    Camion c1;
    Camion c2;

    c1.apagar();
    c1.frenar();
    c2.numSerie="sssssssssss";
    cout<<c1.numSerie<<endl;
    cout<<c2.numSerie<<endl;

    cout<<c2.numSerie<<endl;

    return 0;
}
