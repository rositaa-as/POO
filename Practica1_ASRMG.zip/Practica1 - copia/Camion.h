#ifndef CAMION_H
#define CAMION_H

#include <iostream>

using namespace std;

class Camion
{
    public:
        ///atributos
        string placa;
        string numSerie;
        int numAsientos;

        ///metodos
        Camion();///qtor
        void encender();
        void apagar();
        void frenar();

};

#endif // CAMION_H
