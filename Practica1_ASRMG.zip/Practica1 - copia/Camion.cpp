#include "Camion.h"

#include<iostream>
using namespace std;

Camion::Camion()
{
    numAsientos=30;
    placa="888-555";
    numSerie="1234567890qwertyuiop";
    //ctor
}
void Camion::encender(){

    cout<<"rum rum .."<<endl;
}

void Camion::apagar(){

    cout<<"adios vaquero"<<endl;
}

void Camion::frenar(){

    cout<<"estoy frenando"<<endl;

}
