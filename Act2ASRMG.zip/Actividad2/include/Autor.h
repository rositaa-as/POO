#ifndef AUTOR_H
#define AUTOR_H


class Autor
{
    public:
        ///atributos
        string Nombre;
        string LugarNacimiento;
        int edad;

      ///metodos
        Autor();
        void frase();
        void Tags();
        void Traductora();
};

#endif // AUTOR_H
