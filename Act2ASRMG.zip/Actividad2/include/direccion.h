#ifndef DIRECCION_H
#define DIRECCION_H
#include <iostream>

using namespace std;


class direccion
{
    public:
        direccion();
        direccion(string,int,string,string);

        string calle;
        int numero;
        string ciudad;
        string codigoPostal;

        void sale(void);
        void entra(void);
        void regresa(void);

};

#endif // DIRECCION_H
