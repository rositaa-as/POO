#ifndef EMPLEADO_H
#define EMPLEADO_H
#include "direccion.h"
#include <iostream>

using namespace std;


class Empleado
{
    public:
        Empleado();
        Empleado(string,int,float,direccion);

        string nombre;
        int edad;
        float salario;
        direccion casa;

        void saluda(void);
        void come(void);
        void despedida(void);


    private:
};

#endif // EMPLEADO_H
