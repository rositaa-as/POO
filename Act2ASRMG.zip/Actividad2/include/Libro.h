#ifndef LIBRO_H
#define LIBRO_H


class Libro
{
    public:
         ///atributos
        string Nombre;
        string Editorial;
        int numpaginas;
        class Autor;

        ///metodos
        Libro();
      //  void frase();
      //  void Tags();
       // void Traductora();

};

#endif // LIBRO_H
