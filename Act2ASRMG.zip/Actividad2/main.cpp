#include <iostream>
#include "Empleado.h"
#include "direccion.h"

using namespace std;

int main()
{
    direccion uno("Corregidora",2867,"Guadalajara","44100");
    direccion dos("Neptuno",1580,"Zapopan","58230");

    Empleado Juan("Juan",22,2689.50,dos);


    cout<<Juan.casa.calle<<endl;
    Juan.despedida();

    cout<<Juan.casa.numero<<endl;
    Juan.casa.entra();

    return 0;
}
