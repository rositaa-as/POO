#include "Libro.h"

Libro::Libro()
{
    numpaginas=254;
    Editorial="Puck";
    Nombre="Solo un deseo";//ctor
}
void Libro::frase(){

    cout<<"Algunos lugares son magicos y algunas personas tambien"<<endl;
}

void Libro::Tags(){

    cout<<"amistad, enfermedad,juvenil, superacion"<<endl;
}

void Libro::Traductora(){

    cout<<"N�ria Marti Perez"<<endl;

}


