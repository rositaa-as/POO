#include "Autor.h"

Autor::Autor()
{
    //ctor
}

Autor::~Autor()
{
    //dtor
}
