#include "direccion.h"

direccion::direccion()
{
    calle="comun";
    numero=0;
    ciudad="desconocida";
    codigoPostal="00000";
    //ctor
}
direccion::direccion(string calle,int numero,string ciudad,string codigoPostal)
{
    this->calle=calle;
    this->numero=numero;
    this->ciudad=ciudad;
    this->codigoPostal=codigoPostal;
}
void direccion::entra(void)
{
    cout<<"Al fin en casa..."<<endl;
}
void direccion::regresa(void)
{
    cout<<"Rayos, olvide algo en casa..."<<endl;
}
void direccion::sale(void)
{
    cout<<"*sonido de puerta cerrando*"<<endl;
}

