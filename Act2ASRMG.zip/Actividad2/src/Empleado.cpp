#include "Empleado.h"
#include "direccion.h"

Empleado::Empleado()
{
    nombre="comun";
    edad=0;
    salario=0;
    //direccion=casa;//ctor
}
Empleado::Empleado(string nombre,int edad,float salario,direccion casa)
{
    this->nombre=nombre;
    this->edad=edad;
    this->salario=salario;
    this->casa=casa;
}
void Empleado::saluda(void)
{
    cout<<"Hola,buen d�a!"<<endl;
}
void Empleado::come(void)
{
    cout<<"Que delicioso platillo"<<endl;
}
void Empleado::despedida(void)
{
    cout<<"Adios, hasta pronto"<<endl;
}

